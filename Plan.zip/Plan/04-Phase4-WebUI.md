# 阶段四 — WebUI (P2，可选)

目标：为已完成的 Agent Runtime 增加一个最小 Web 交互层，用于演示，而不改动 Runtime 核心。
定位：**可选、最后做**。仅当阶段一~三全部完成且时间充裕才启动；否则明确不做，避免抢占核心时间。

前置条件：阶段一~三验收通过，CLI 版本已可稳定演示。

---

## A. SPEC（做什么）

### A.1 交付清单（若启动）

- [ ] 一个本地 Web 服务，浏览器输入任务、查看 Agent 运行过程
- [ ] 复用同一个 Agent / Context / Registry，不 fork 逻辑
- [ ] 流式或分步展示：每轮 tool 调用、tool 结果、最终答案
- [ ] Permission 与 ask_user 的 Web 交互通道（替换 CLI readline）

### A.2 非目标

- 不做账号、多会话持久化、复杂前端框架、部署。
- 不追求样式，够演示即可。

---

## B. 设计（怎么做）

### B.1 核心复用原则

- Runtime 不变：Web 层只是新的"UI 适配器"，注入方式与 CLI 平行。
- 关键抽象：把 CLI 的交互能力抽象成一个 `Interactor` 接口：
  ```ts
  interface Interactor {
    prompt(question: string): Promise<string>;   // ask_user / permission 都用
    onEvent(e: AgentEvent): void;                 // 展示 tool 调用/结果/答案
  }
  ```
- CLI 实现走 readline + console；Web 实现走 WebSocket/SSE + 前端表单。
- `PermissionService` 与 `ask_user` 依赖 `Interactor` 而非直接依赖 readline，从而 CLI/Web 可切换。

### B.2 技术选型（最小）

```text
后端：Express + ws（或 SSE）
前端：单个静态 HTML + 原生 JS（无构建）
```

### B.3 事件流

```text
POST /run { task, workspace }
  → 后端创建 Context(Web Interactor) + Agent
  → Agent 逐轮产出 AgentEvent
  → 通过 WS/SSE 推给前端渲染
  → 遇到 ask_user / dangerous 工具 → 前端弹输入/批准 → 回传 → 恢复
```

### B.4 设计要点 / 取舍

- 若为接 Web 而需要给 CLI 的交互逻辑做抽象重构，应在阶段二就预留 `Interactor`（低成本）。
- 安全提醒：Web 服务默认无鉴权，仅限本地演示；README 需明确标注"本地 only、勿暴露公网"。

---

## C. 验收条件

- [ ] 浏览器输入任务能跑通 Case 1 / Case 2。
- [ ] 运行过程分步可见（tool 调用、结果、最终答案）。
- [ ] ask_user 在网页上可问答并恢复。
- [ ] dangerous 工具在网页上可批准/拒绝。
- [ ] Runtime 核心（Agent Loop / Registry / Tool）相较 CLI 版无逻辑分叉，仅新增 Web Interactor。
- [ ] README 增补 Web 启动方式与"本地 only"安全说明。

---

## D. 时间不足时的决策

```text
若时间不足 → 不做 WebUI。
优先保证：Agent Loop + DI + Tool Registry + Permission + ask_user 完整可演示。
```
